# Course Materials Assistant

<div align="center">

**A local-first bilingual study workflow for English-medium courses**<br>
**面向中外合作项目学生与国际学生的本地优先双语课程学习工作流**

[![Tests](https://github.com/D0NO1/course-materials-assistant/actions/workflows/tests.yml/badge.svg)](https://github.com/D0NO1/course-materials-assistant/actions/workflows/tests.yml)
[![License](https://img.shields.io/github/license/D0NO1/course-materials-assistant)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-3776AB?logo=python&logoColor=white)](pyproject.toml)

</div>

Course Materials Assistant turns mixed course files into source-backed bilingual study notes, learning sessions, assignment trackers, and cumulative Final Exam review files.

Course Materials Assistant 可以把混合课程文件整理成有来源依据的双语学习笔记、学习任务、作业追踪表和累计式 Final Exam 考点复习材料。

It is designed for students who study professional subjects in English and need a clearer bridge between course language, course structure, and exam preparation.

它面向使用英语学习专业课程的学生，帮助你把英文课程目标、课堂材料、作业要求和期末复习连接起来。

## Why This Project

Many course folders contain PDFs, Word assignments, PowerPoint lectures, spreadsheets, database files, and personal notes at the same time. The project provides one repeatable local workflow:

很多课程文件夹同时包含 PDF、Word 作业、PowerPoint 课件、Excel 表格、Access 数据库和个人笔记。本项目提供一套可重复使用的本地工作流：

```text
scan  ->  extract/analyze  ->  learn  ->  review  ->  exam preparation
扫描      提取/分析            学习       复习       期末考试准备
```

The assistant keeps source references visible, preserves source files, and separates course-confirmed evidence from assistant-priority suggestions.

助手会尽量保留来源定位，不修改原始课程文件，并区分“课程材料明确支持的内容”和“助手建议优先复习的内容”。

## What You Can Do

| Need / 学习需求 | Command / 命令 | Main result / 主要结果 |
|---|---|---|
| Build a course index / 建立课程索引 | `scan` | SHA-256 tracked `index.json` and readable `index.md` |
| Extract file content / 提取文件内容 | `extract` | Normalized JSON with page, slide, heading, or sheet locators |
| Analyze a whole course folder / 分析整个课程文件夹 | `analyze` | `extracted-materials.json` |
| Prepare before class / 课前预习 | `learn --mode preview` | Goals, prerequisites, questions, and reading priority |
| Understand difficult material / 理解难点 | `learn --mode understand` | Plain-English explanation with Chinese support |
| Review after class / 课后复习 | `learn --mode review` | Bilingual key points and self-test prompts |
| Track assignments / 追踪作业 | `learn --mode assignment` or `assignments` | Requirements, dates, conflicts, and submission checklist |
| Prepare for the Final Exam / 准备期末考试 | `learn --mode exam` or `exam-review` | Cumulative topics, comparisons, process checklists, and study prompts |

## Supported Materials

| Format / 格式 | Indexing / 索引 | Deep extraction / 深度提取 | Evidence / 来源定位 |
|---|---|---|---|
| PDF | Yes | Yes, when readable | Page numbers / 页码 |
| Word `.docx` | Yes | Yes | Headings and paragraphs / 标题与段落 |
| PowerPoint `.pptx` | Yes | Yes | Slide numbers, titles, notes / 幻灯片编号、标题、备注 |
| Excel `.xlsx`, `.xlsm` | Yes | Yes | Sheet names and cell/table context / 工作表与单元格或表格 |
| Access `.accdb`, `.mdb` | Yes | Inventory-oriented | Tables, queries, forms, reports, and other objects when supported |
| Legacy `.doc`, `.xls`, `.ppt` | Yes | Depends on local parser support | File-level inventory first / 先完成文件级索引 |

Access macros are not executed and source databases are not mutated during ordinary analysis.

普通分析不会执行 Access 宏，也不会修改源数据库。

## Quick Start

### 1. Install dependencies

```powershell
python -m pip install -r requirements.txt
```

The project requires Python 3.11 or newer. LibreOffice is optional and is only needed when you want page-level rendering checks for generated Word reports.

本项目需要 Python 3.11 或更高版本。LibreOffice 不是必需依赖，只有在需要对生成的 Word 报告进行逐页渲染检查时才需要。

### 2. Index a course folder

```powershell
python scripts/cli.py scan "D:\Courses\MIS-413-91 - Systems Analysis"
```

The index is written to the course folder's `.course-assistant` directory. The source files stay where they are.

索引会写入课程文件夹中的 `.course-assistant` 目录，原始课程文件仍然保留在原位置。

### 3. Generate a bilingual learning session

```powershell
python scripts/cli.py learn "D:\Courses\MIS-413-91 - Systems Analysis" --mode preview
python scripts/cli.py learn "D:\Courses\MIS-413-91 - Systems Analysis" --mode understand
python scripts/cli.py learn "D:\Courses\MIS-413-91 - Systems Analysis" --mode review
python scripts/cli.py learn "D:\Courses\MIS-413-91 - Systems Analysis" --mode assignment
python scripts/cli.py learn "D:\Courses\MIS-413-91 - Systems Analysis" --mode exam
```

Each `learn` command writes a bilingual JSON learning file and, by default, a timestamped Word report under `.course-assistant\reports\`.

每条 `learn` 命令默认都会生成一个双语 JSON 学习文件，并在 `.course-assistant\reports\` 下生成带时间戳的 Word 报告。

To generate JSON only:

```powershell
python scripts/cli.py learn "D:\Courses\MIS-413-91 - Systems Analysis" --mode review --no-docx
```

### 4. Create cumulative review files

```powershell
python scripts/cli.py exam-review "D:\Courses\MIS-413-91 - Systems Analysis"
python scripts/cli.py assignments "D:\Courses\MIS-413-91 - Systems Analysis"
```

The Final Exam workflow is cumulative. It uses analyzed and source-supported findings; it does not claim to know the actual exam questions.

Final Exam 工作流会持续累积已经分析并有来源依据的内容，但不会声称知道老师的真实考试题目。

## CLI Reference

```text
python scripts/cli.py scan <course_root>
python scripts/cli.py extract <file-or-folder> [--output <output.json>]
python scripts/cli.py analyze <course_root>
python scripts/cli.py learn <course_root> --mode <preview|understand|review|assignment|exam>
python scripts/cli.py exam-review <course_root>
python scripts/cli.py assignments <course_root>
```

The `learn` command also accepts `--config <config.json>` and `--no-docx`.

`learn` 命令还支持 `--config <config.json>` 和 `--no-docx` 参数。

### Learning Modes

| Mode | English purpose | 中文用途 |
|---|---|---|
| `preview` | Identify course goals, prerequisites, questions, and reading priority before class. | 识别课前目标、先修知识、预习问题和阅读优先级。 |
| `understand` | Explain the material in plain English with Chinese support and concept relationships. | 用较易理解的英文和中文辅助解释材料及概念关系。 |
| `review` | Review bilingual key points and test yourself after class. | 课后复习双语重点并进行自测。 |
| `assignment` | Organize deliverables, requirements, dates, conflicts, and submission checks. | 整理作业交付物、要求、日期、冲突和提交检查项。 |
| `exam` | Build a cumulative Final Exam focus guide from the available course evidence. | 根据已有课程证据建立累计式 Final Exam 考点指南。 |

## Bilingual Output

The default language mode is `en-zh`: one English point first, followed immediately by its Chinese explanation.

默认语言模式是 `en-zh`：先写一条英文内容，紧接着写对应的中文解释。

```text
Systems analysis identifies business needs before system design begins.
系统分析在系统设计开始之前识别业务需求。

The SDLC organizes systems work from planning and analysis through design, testing, and maintenance.
系统开发生命周期（SDLC）把系统工作从规划、分析推进到设计、测试和维护。
```

Supported language modes are `en-zh`, `zh-en`, `english-only`, `chinese-support`, and `plain-english`.

支持的语言模式包括 `en-zh`、`zh-en`、`english-only`、`chinese-support` 和 `plain-english`。

Use [`examples/config.example.json`](examples/config.example.json) to configure language order, audience, Word generation, rendering checks, and cumulative exam behavior.

可以使用 [`examples/config.example.json`](examples/config.example.json) 配置语言顺序、目标学生、Word 生成、渲染检查和累计式考试复习行为。

## Generated Files

```text
course-folder/
└── .course-assistant/
    ├── index.json
    ├── index.md
    ├── extracted-materials.json
    ├── 01-课前预习-双语.json
    ├── 02-课堂理解-双语.json
    ├── 03-课后复习-双语.json
    ├── 04-作业任务-双语.json
    ├── 05-期末考试考点复习-双语.json
    ├── glossary.json
    ├── topics.json
    ├── assignments.json
    ├── milestones.json
    ├── exam_focus.json
    ├── final-exam-review.json
    ├── final-exam-review.md
    ├── assignment-tracker.json
    ├── assignment-tracker.md
    └── reports/
        └── <timestamp>-<analysis>.docx
```

Generated course data is intentionally ignored by Git. This keeps the public repository focused on reusable code and prevents private course materials from being published accidentally.

生成的课程数据默认被 Git 忽略。这样可以让公开仓库只保留可复用代码，并降低误上传私人课程材料的风险。

## Project Layout

```text
course-materials-assistant/
├── agents/openai.yaml                 # Codex agent metadata
├── examples/config.example.json       # Example learning configuration
├── scripts/                           # CLI, indexers, extractors, and generators
├── tests/                             # Regression tests
├── SKILL.md                           # Codex skill instructions
├── SECURITY.md                        # Security and privacy policy
├── pyproject.toml                     # Package metadata and dependencies
└── requirements.txt                   # Runtime dependencies
```

## Privacy and Safety

- The normal scripts process course files locally and do not upload them to an external API.
- 普通脚本在本地处理课程文件，不会把课程文件上传到外部 API。
- Do not commit real course materials, student identifiers, databases, generated reports, API keys, tokens, or `.env` files.
- 不要提交真实课程材料、学生身份信息、数据库、生成的报告、API key、令牌或 `.env` 文件。
- Extracted JSON keeps a local `path` field for traceability. Review that field before sharing extracted data.
- 提取后的 JSON 会保留本地 `path` 字段用于追溯，分享前请检查其中是否包含用户名或私人目录。
- Review `git status` before every public push.
- 每次公开推送前都要检查 `git status`。

See [`SECURITY.md`](SECURITY.md) for the reporting policy.

## Limitations

- Deep extraction depends on the parser dependencies and the actual file contents.
- 深度提取效果取决于解析依赖是否安装，以及源文件本身是否可读。
- Scanned PDFs and image-only slides may require OCR or visual review.
- 扫描版 PDF 和只有图片的幻灯片可能需要 OCR 或人工视觉检查。
- Access support is inventory-oriented in this release; macros are not executed.
- 当前版本的 Access 支持以结构清单为主，不执行宏。
- LibreOffice rendering is optional and platform-dependent.
- LibreOffice 渲染检查是可选的，并且取决于本地平台环境。
- The repository provides scripts and a Codex skill, not a standalone packaged desktop application.
- 本仓库提供脚本和 Codex skill，不是独立的桌面应用程序。

## Development

Install the dependencies and run the test suite:

```powershell
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

GitHub Actions runs the same test suite on Python 3.11 and 3.12.

GitHub Actions 会在 Python 3.11 和 3.12 环境中运行同一套测试。

When changing behavior, add a focused regression test and keep source-file safety intact.

修改行为时，请补充针对性的回归测试，并保持原始课程文件安全不被覆盖。

## License

MIT License. See [`LICENSE`](LICENSE).
